const sql = require("../db/sql");
const { listResolvedIntentCandidates } = require("../planner/metricRegistry");
const { buildUserContext } = require("./userContextService");

async function getCatalog() {
  const intents = listResolvedIntentCandidates().map((m) => ({
    intent: m.intent,
    metric_id: m.metric_id,
    description_tr: m.description_tr || "",
    domain: detectDomain(m.intent, m.metric_id),
  }));

  return { intents };
}

function detectDomain(intent, metricId = "") {
  const text = `${intent || ""} ${metricId || ""}`.toLowerCase();
  if (text.includes("visit") || text.includes("dynamic")) return "visit";
  if (text.includes("user")) return "users";
  if (text.includes("client") || text.includes("distributor") || text.includes("consumer")) return "client";
  if (text.includes("invoice") || text.includes("purchase") || text.includes("campaign") || text.includes("payment")) return "sales";
  return "other";
}

async function getSubscriptions(search) {
  const result = await sql.query(`
    SELECT TOP 100 Id AS id, CompanyName AS label
    FROM dbo.Subscription
    WHERE Deleted = 0
      AND (@search IS NULL OR CompanyName LIKE '%' + @search + '%')
    ORDER BY CompanyName
  `, { search: search || null });

  return { items: result.recordset };
}

async function getBrands({ subscriptionId, search }) {
  const result = await sql.query(`
    SELECT TOP 100 Id AS id, Name AS label, SubscriptionId AS subscriptionId
    FROM dbo.Brand
    WHERE Deleted = 0
      AND (@subscriptionId IS NULL OR SubscriptionId = @subscriptionId)
      AND (@search IS NULL OR Name LIKE '%' + @search + '%')
    ORDER BY Name
  `, {
    subscriptionId: subscriptionId ? Number(subscriptionId) : null,
    search: search || null,
  });

  return { items: result.recordset };
}

async function getClients({ subscriptionId, search, limit }) {
  const result = await sql.query(`
    SELECT TOP (@limit)
      Id AS id,
      Name AS label,
      SubscriptionId AS subscriptionId
    FROM dbo.Client
    WHERE Deleted = 0
      AND (@subscriptionId IS NULL OR SubscriptionId = @subscriptionId)
      AND (@search IS NULL OR Name LIKE '%' + @search + '%')
    ORDER BY Name
  `, {
    subscriptionId: subscriptionId ? Number(subscriptionId) : null,
    search: search || null,
    limit: Number(limit) || 100,
  });

  return { items: result.recordset };
}

async function getUsers({ search, limit }) {
  const result = await sql.query(`
    SELECT TOP (@limit)
      Id AS id,
      Name AS name,
      Email AS email,
      SubscriptionId AS subscriptionId,
      Blocked AS blocked
    FROM dbo.[User]
    WHERE Deleted = 0
      AND (@search IS NULL OR Name LIKE '%' + @search + '%' OR Email LIKE '%' + @search + '%')
    ORDER BY Id DESC
  `, {
    search: search || null,
    limit: Number(limit) || 50,
  });

  return { items: result.recordset };
}

async function getRoles({ subscriptionId }) {
  const result = await sql.query(`
    SELECT
      Id AS id,
      Name AS name,
      Code AS code,
      SubscriptionId AS subscriptionId,
      DefaultAdmin AS defaultAdmin
    FROM dbo.Role
    WHERE Deleted = 0
      AND (@subscriptionId IS NULL OR SubscriptionId = @subscriptionId)
    ORDER BY Name
  `, {
    subscriptionId: subscriptionId ? Number(subscriptionId) : null,
  });

  return { items: result.recordset };
}

async function getRolePermissions(roleId) {
  const result = await sql.query(`
    SELECT Intent
    FROM dbo.AiRolePermission
    WHERE Deleted = 0
      AND RoleId = @roleId
    ORDER BY Intent
  `, { roleId: Number(roleId) });

  return {
    allowedIntents: result.recordset.map((x) => x.Intent),
  };
}

async function saveRolePermissions(roleId, allowedIntents = [], actorUserId = "system") {
  await sql.query(`
    UPDATE dbo.AiRolePermission
    SET Deleted = 1, UpdateTime = GETDATE(), UpdatedBy = @actorUserId
    WHERE RoleId = @roleId AND Deleted = 0
  `, {
    roleId: Number(roleId),
    actorUserId: String(actorUserId),
  });

  for (const intent of allowedIntents) {
    await sql.query(`
      INSERT INTO dbo.AiRolePermission (RoleId, Intent, UpdatedBy)
      VALUES (@roleId, @intent, @actorUserId)
    `, {
      roleId: Number(roleId),
      intent,
      actorUserId: String(actorUserId),
    });
  }

  return { ok: true };
}

async function getUserRoles(userId) {
  const result = await sql.query(`
    SELECT RoleId
    FROM dbo.UserRole
    WHERE Deleted = 0
      AND UserId = @userId
  `, { userId: Number(userId) });

  return {
    roleIds: result.recordset.map((x) => x.RoleId),
  };
}

async function saveUserRoles(userId, roleIds = [], actorUserId = "system") {
  await sql.query(`
    UPDATE dbo.UserRole
    SET Deleted = 1, UpdateTime = GETDATE(), UpdatedBy = @actorUserId
    WHERE UserId = @userId AND Deleted = 0
  `, {
    userId: Number(userId),
    actorUserId: String(actorUserId),
  });

  for (const roleId of roleIds) {
    await sql.query(`
      INSERT INTO dbo.UserRole
      (CreateTime, UpdateTime, UpdatedBy, Deleted, UserId, RoleId)
      VALUES
      (GETDATE(), GETDATE(), @actorUserId, 0, @userId, @roleId)
    `, {
      userId: Number(userId),
      roleId: Number(roleId),
      actorUserId: String(actorUserId),
    });
  }

  return { ok: true };
}

async function getUserScopes(userId) {
  const result = await sql.query(`
    SELECT ScopeType, ScopeValue
    FROM dbo.AiUserScope
    WHERE Deleted = 0
      AND UserId = @userId
  `, { userId: Number(userId) });

  const scopes = {
    allowedSubscriptionIds: null,
    allowedCompanyIds: null,
    allowedBrandIds: null,
    allowedClientIds: null,
    allowedCountryIds: null,
    allowedRegionIds: null,
    allowedCityIds: null,
    allowedDistrictIds: null,
  };

  for (const row of result.recordset) {
    const key = row.ScopeType;
    const value = Number(row.ScopeValue);

    if (key === "subscription" || key === "company") {
      scopes.allowedSubscriptionIds ||= [];
      scopes.allowedCompanyIds ||= [];
      scopes.allowedSubscriptionIds.push(value);
      scopes.allowedCompanyIds.push(value);
    }

    if (key === "brand") {
      scopes.allowedBrandIds ||= [];
      scopes.allowedBrandIds.push(value);
    }

    if (key === "client") {
      scopes.allowedClientIds ||= [];
      scopes.allowedClientIds.push(value);
    }

    if (key === "country") {
      scopes.allowedCountryIds ||= [];
      scopes.allowedCountryIds.push(value);
    }

    if (key === "region") {
      scopes.allowedRegionIds ||= [];
      scopes.allowedRegionIds.push(value);
    }

    if (key === "city") {
      scopes.allowedCityIds ||= [];
      scopes.allowedCityIds.push(value);
    }

    if (key === "district") {
      scopes.allowedDistrictIds ||= [];
      scopes.allowedDistrictIds.push(value);
    }
  }

  return scopes;
}

async function saveUserScopes(userId, scopes = {}, actorUserId = "system") {
  await sql.query(`
    UPDATE dbo.AiUserScope
    SET Deleted = 1, UpdateTime = GETDATE(), UpdatedBy = @actorUserId
    WHERE UserId = @userId AND Deleted = 0
  `, {
    userId: Number(userId),
    actorUserId: String(actorUserId),
  });

  const items = [
    ["subscription", scopes.allowedSubscriptionIds || scopes.allowedCompanyIds],
    ["brand", scopes.allowedBrandIds],
    ["client", scopes.allowedClientIds],
    ["country", scopes.allowedCountryIds],
    ["region", scopes.allowedRegionIds],
    ["city", scopes.allowedCityIds],
    ["district", scopes.allowedDistrictIds],
  ];

  for (const [scopeType, values] of items) {
    for (const value of values || []) {
      await sql.query(`
        INSERT INTO dbo.AiUserScope
        (UserId, ScopeType, ScopeValue, UpdatedBy)
        VALUES
        (@userId, @scopeType, @scopeValue, @actorUserId)
      `, {
        userId: Number(userId),
        scopeType,
        scopeValue: String(value),
        actorUserId: String(actorUserId),
      });
    }
  }

  return { ok: true };
}

async function getEffectivePermissions(userId) {
  const context = await buildUserContext(userId);
  const roleIds = context.roleIds || [];

  let isSuperAdmin = !!context.flags?.admin;
  const allowedIntentSet = new Set();

  for (const roleId of roleIds) {
    const perms = await getRolePermissions(roleId);
    for (const intent of perms.allowedIntents) {
      if (intent === "*") isSuperAdmin = true;
      allowedIntentSet.add(intent);
    }
  }

  const customScopes = await getUserScopes(userId);

  return {
  userId: Number(userId),
  subscriptionId: context.subscriptionId,
  tenantId: context.tenantId,

  roleIds,
  roles: context.roles || [],

  isSuperAdmin,
  isAdmin: isSuperAdmin,
  isClientUser: context.isClientUser,
  manageAll: context.manageAll,

  allowedIntents: isSuperAdmin ? ["*"] : [...allowedIntentSet].filter((x) => x !== "*"),
  allowedMetrics: isSuperAdmin ? ["*"] : context.allowedMetrics || [],
  allowedTables: isSuperAdmin ? ["*"] : context.allowedTables || [],

  allowedColumns: context.allowedColumns || [],
  maskedColumns: context.maskedColumns || [],
  blockedColumns: context.blockedColumns || [],

  allowedUserIds: context.allowedUserIds || [Number(userId)],
  assignedClientIds: context.assignedClientIds || [],
  effectiveClientIds: customScopes.allowedClientIds ?? context.effectiveClientIds ?? [],

  clientTagIds: context.clientTagIds || [],
  managedTeamIds: context.managedTeamIds || [],

  allowedCompanyIds: customScopes.allowedSubscriptionIds ?? context.allowedCompanyIds ?? [],
  allowedSubscriptionIds: customScopes.allowedSubscriptionIds ?? context.allowedSubscriptionIds ?? [],

  allowedBrandIds: customScopes.allowedBrandIds ?? context.allowedBrandIds ?? [],
  allowedRegionIds: context.allowedRegionIds || [],
  allowedCountryIds: context.allowedCountryIds || [],
  allowedCityIds: context.allowedCityIds || [],
  allowedDistrictIds: context.allowedDistrictIds || [],

  allowedDistributorIds: context.allowedDistributorIds || [],
  allowedClientGroupIds: context.allowedClientGroupIds || [],

  allowedDynamicFieldIds: context.allowedDynamicFieldIds || [],
  blockedDynamicFieldIds: context.blockedDynamicFieldIds || [],
  maskedDynamicFieldIds: context.maskedDynamicFieldIds || [],

  allowedFinancialMetrics: isSuperAdmin ? ["*"] : context.allowedFinancialMetrics || [],
  };
}

module.exports = {
  getCatalog,
  getSubscriptions,
  getBrands,
  getClients,
  getUsers,
  getRoles,
  getRolePermissions,
  saveRolePermissions,
  getUserRoles,
  saveUserRoles,
  getUserScopes,
  saveUserScopes,
  getEffectivePermissions,
};