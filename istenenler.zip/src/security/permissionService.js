const { getMetricByIntent } = require("../planner/metricRegistry");

function isAdmin(userContext) {
  return (
    userContext?.isAdmin === true ||
    userContext?.flags?.admin === true ||
    userContext?.accessMode?.isGlobalAdmin === true
  );
}

function normalizeTableName(tableName = "") {
  return String(tableName)
    .replace("[", "")
    .replace("]", "")
    .trim()
    .toLowerCase();
}

function listIncludesNormalized(list = [], value = "") {
  const normalizedValue = normalizeTableName(value);
  return list.map(normalizeTableName).includes(normalizedValue);
}

function getAllowedList(userContext, key) {
  return userContext?.[key] || [];
}

function checkIntentPermission(userContext, intent) {
  if (isAdmin(userContext)) return { ok: true };

  const allowedIntents = getAllowedList(userContext, "allowedIntents");

  if (!allowedIntents.length) {
    return {
      ok: false,
      reason: "INTENT_PERMISSION_EMPTY",
      message: "Bu kullanıcı için intent yetkisi tanımlı değil.",
    };
  }

  if (!allowedIntents.includes("*") && !allowedIntents.includes(intent)) {
    return {
      ok: false,
      reason: "INTENT_NOT_ALLOWED",
      message: "Bu soruyu çalıştırma yetkiniz yok.",
    };
  }

  return { ok: true };
}

function checkMetricPermission(userContext, metric) {
  if (isAdmin(userContext)) return { ok: true };

  const allowedMetrics = getAllowedList(userContext, "allowedMetrics");

  if (!allowedMetrics.length) {
    return {
      ok: false,
      reason: "METRIC_PERMISSION_EMPTY",
      message: "Bu kullanıcı için metric yetkisi tanımlı değil.",
    };
  }

  if (!allowedMetrics.includes("*") && !allowedMetrics.includes(metric.metric_id))
    {
    return {
      ok: false,
      reason: "METRIC_NOT_ALLOWED",
      message: "Bu metriği çalıştırma yetkiniz yok.",
    };
  }

  return { ok: true };
}

function checkTablePermission(userContext, metric) {
  if (isAdmin(userContext)) return { ok: true };

  const allowedTables = getAllowedList(userContext, "allowedTables");
  const sourceTables = metric.source_tables || [];

  if (!allowedTables.length) {
    return {
      ok: false,
      reason: "TABLE_PERMISSION_EMPTY",
      message: "Bu kullanıcı için tablo yetkisi tanımlı değil.",
    };
  }

  if (allowedTables.includes("*")) {
    return { ok: true };
  }

  const blockedTable = sourceTables.find(
    (tableName) => !listIncludesNormalized(allowedTables, tableName)
  );

  if (blockedTable) {
    return {
      ok: false,
      reason: "TABLE_NOT_ALLOWED",
      message: `Bu sorgu için gerekli tabloya erişim yetkiniz yok: ${blockedTable}`,
    };
  }

  return { ok: true };
}

function checkSecurityScope(userContext, metric) {
  const scope = metric.security_scope || "tenant_user_scope";

  if (isAdmin(userContext)) return { ok: true };

  if (scope === "subscription_user_scope") {
    if (!userContext?.subscriptionId) {
      return {
        ok: false,
        reason: "SUBSCRIPTION_SCOPE_MISSING",
        message: "Kullanıcı subscription bilgisi bulunamadı.",
      };
    }
  }

  if (scope === "tenant_user_scope") {
    if (!userContext?.subscriptionId) {
      return {
        ok: false,
        reason: "TENANT_SCOPE_MISSING",
        message: "Tenant/subscription bilgisi bulunamadı.",
      };
    }
  }

  if (scope === "client_scope") {
    const clientIds = userContext?.scopes?.clientIds || [];

    if (!clientIds.length) {
      return {
        ok: false,
        reason: "CLIENT_SCOPE_EMPTY",
        message: "Bu kullanıcıya atanmış müşteri erişimi bulunmuyor.",
      };
    }
  }

  return { ok: true };
}

function authorizeIntent(userContext, intent) {
  const metric = getMetricByIntent(intent);

  if (!metric) {
    return {
      ok: false,
      reason: "METRIC_NOT_FOUND",
      message: `Intent için metric bulunamadı: ${intent}`,
    };
  }

  const checks = [
    checkIntentPermission(userContext, intent),
    checkMetricPermission(userContext, metric),
    checkTablePermission(userContext, metric),
    checkSecurityScope(userContext, metric),
  ];

  const failed = checks.find((check) => !check.ok);

  if (failed) {
    return {
      ...failed,
      metric,
    };
  }

  return {
    ok: true,
    metric,
    security_scope: metric.security_scope,
    source_tables: metric.source_tables || [],
  };
}

module.exports = {
  isAdmin,
  authorizeIntent,
  checkIntentPermission,
  checkMetricPermission,
  checkTablePermission,
  checkSecurityScope,
};