const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_change_me";

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || "";

  if (!authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Token bulunamadi." });
  }

  const token = authHeader.replace("Bearer ", "").trim();

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    req.authUser = {
      userId: decoded.userId,
      email: decoded.email,
      subscriptionId: decoded.subscriptionId,
      admin: !!decoded.admin,
      apiUser: !!decoded.apiUser,
      clientUser: !!decoded.clientUser,
    };

    return next();
  } catch (error) {
    return res.status(401).json({ error: "Token gecersiz veya suresi dolmus." });
  }
}

module.exports = { authMiddleware };